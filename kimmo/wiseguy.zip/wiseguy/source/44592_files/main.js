function highlightReply(id)
{
	var divs = document.getElementsByTagName('div');

	for (var i = 0; i < divs.length; i++)
	{
		if (divs[i].className.indexOf('post_body') != -1)
			divs[i].className = divs[i].className.replace(/highlighted/, '');
	}

	if (id)
		document.getElementById('reply_box_' + id).className += ' highlighted';
}

function focusId(id)
{
	document.getElementById(id).focus();
	init();
}

function breakOutFromJail()
{
	if (top.location != location)
		top.location.href = window.location.href;
}

function fixLinksForRetards()
{
	var as = document.links;

	for (var i = 0; i < as.length; i++)
	{
		if (as[i].href && (as[i].rel.indexOf('new') != -1))
			as[i].target = '_blank';
	}
}

function checkOrUncheckAllCheckboxes()
{
	tmp = document.fuck_off;

	for (i = 0; i < tmp.elements.length; i++)
	{
		if (tmp.elements[i].type == 'checkbox')
		{
			if (tmp.master_checkbox.checked == true)
				tmp.elements[i].checked = true;
			else
				tmp.elements[i].checked = false;
		}
	}
}

function submitDummyForm(theAction, theVariableName, theVariableValue, confirmMessage)
{
	if (confirmMessage === undefined)
		var tmp = confirm('Really?');
	else
		var tmp = confirm(confirmMessage);

	if (tmp)
	{
		var form = document.getElementById('dummy_form');
		form.action = theAction;
		form.some_var.name = theVariableName;
		form.some_var.value = theVariableValue;
		form.do_submit.value = '1';
		form.submit();
	}

	return false;
}

function confirmAbuseReportPoster(theAction, theVariableName, theVariableValue)
{
	submitDummyForm(theAction, theVariableName, theVariableValue, 'Really abuse report that poster? Please don\'t abuse report just because of controversial opinions; that only wastes everyone\'s time.');
	return false;
}

function updateCharactersLeft(theInputOrTextarea, theElementToUpdate, maxCharacters)
{
	tmp = document.getElementById(theElementToUpdate);
	tmp.firstChild.data = maxCharacters - document.getElementById(theInputOrTextarea).value.length;
}

function printCrapForTheFuckingShit(idOfTrackerElement, numDefaultCharacters)
{
	document.write(' (<STRONG ID="' + idOfTrackerElement + '">' + numDefaultCharacters + '</STRONG> left)');
}

function removeSnapbackLink()
{
	var tmp = document.getElementById("snapback_link");

	if (tmp)
		tmp.parentNode.removeChild(tmp);
}

function createSnapbackLink(lastReplyId)
{
	removeSnapbackLink();

	var div = document.createElement('DIV');
	div.id = 'snapback_link';
	var a = document.createElement('A');
	a.href = '#reply_' + lastReplyId;
	a.onclick = function () { highlightReply(lastReplyId); removeSnapbackLink(); };
	a.className = 'help_cursor';
	a.title = 'Click me to snap back!';
	var strong = document.createElement('STRONG');
	strong.appendChild(document.createTextNode('↕'));
	a.appendChild(strong);
	div.appendChild(a);
	document.body.appendChild(div);
}

function init()
{
	breakOutFromJail();
	fixLinksForRetards();

	if (document.getElementById(window.location.hash.substring(1)) && window.location.hash.indexOf('reply_') != -1)
		highlightReply(window.location.hash.substring(7));
}

window.onload = init;
